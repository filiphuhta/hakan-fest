
async function fetchCocktail() {
  const response = await fetch('https://www.thecocktaildb.com/api/json/v1/1/random.php');
  const cocktail = await response.json();
  return cocktail;
}


async function addCocktail() {
  let dataPromise = fetchCocktail();
  let cocktail;

  await dataPromise.then(d => {
    cocktail = d.drinks[0];
  });

  console.log(cocktail);
  let div = document.getElementById("cocktail");
  div.innerHTML = '<div class="drink-container">' +
    `<h3"> ${cocktail.strDrink}</h3>` +
    `<p>Kategori: ${cocktail.strCategory}</p>` +
    `<img src="${cocktail.strDrinkThumb}" style="width: 200; height: 200;" />` +
    `<h4>Innehållslista osv</h4>` +
    `<p>Föredraget Glas: ${cocktail.strGlass}</p>` +
    `<p>${cocktail.strIngredient1}</p>` +
    `<p>${cocktail.strIngredient2}</p>` +
    `<p>${cocktail.strIngredient3}</p>` +
    `<p>${cocktail.strIngredient4}</p>` +
    `<p>${cocktail.strIngredient5}</p>` +
    `<p>${cocktail.strIngredient6}</p>` +
    `<p>${cocktail.strIngredient7}</p>` +
    `<p>${cocktail.strIngredient8}</p>` +
    `<p>${cocktail.strIngredient9}</p>` +
    `<p>${cocktail.strIngredient10}</p>` +
    `<p>${cocktail.strIngredient11}</p>` +
    `<p>${cocktail.strIngredient12}</p>` +
    `<p>${cocktail.strIngredient13}</p>` +
    `<h3>Gör såhär</h3>` +
    `<p>${cocktail.strInstructions}</p>` +
    '</div>';
}

addCocktail();

